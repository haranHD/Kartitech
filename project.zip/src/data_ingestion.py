import PyPDF2
import docx
import pandas as pd
import pytesseract
from PIL import Image
import io
from pathlib import Path
from typing import List, Dict, Any, Optional
import logging
from .utils import generate_document_id, clean_text, chunk_text, extract_metadata

logger = logging.getLogger(__name__)

class DocumentProcessor:
    """Handles document ingestion, OCR, and text extraction"""
    def __init__(self, config):
        self.config = config
        self.supported_formats = {'.pdf', '.docx', '.doc', '.txt'}

    def extract_text_from_pdf(self, file_path: Path) -> str:
        """Extract text from PDF files using text extraction and OCR fallback"""
        text = ""
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                # First, try to extract text normally
                for page_num, page in enumerate(pdf_reader.pages):
                    page_text = page.extract_text()
                    if page_text.strip():
                        text += f"\n[Page {page_num + 1}]\n{page_text}\n"
            
            # If no text was extracted, try OCR on the whole document
            if not text.strip():
                logger.warning("Standard text extraction failed. Attempting OCR on the entire PDF.")
                try:
                    # This requires converting each PDF page to an image.
                    # This is a simplified approach, a more robust solution would be needed in production.
                    from pdf2image import convert_from_path
                    images = convert_from_path(file_path)
                    for i, image in enumerate(images):
                        page_text = pytesseract.image_to_string(image, lang=self.config.OCR_LANGUAGE)
                        text += f"\n[OCR Page {i + 1}]\n{page_text}\n"
                except ImportError:
                    logger.error("pdf2image library not found. Please install it with 'pip install pdf2image'.")
                    return ""
                except Exception as e:
                    logger.error(f"OCR failed for PDF {file_path}: {e}")
                    return ""

        except Exception as e:
            logger.error(f"Error extracting text from PDF {file_path}: {e}")
            return ""

        if not text.strip():
            logger.warning(f"No text could be extracted from {file_path.name} even with OCR.")
            return ""

        return clean_text(text)

    def _ocr_pdf_page(self, page) -> str:
        """Perform OCR on a single PDF page object"""
        try:
            # This method will be deprecated by the new full PDF OCR logic
            return pytesseract.image_to_string(
                page,
                lang=self.config.OCR_LANGUAGE,
                config='--psm 6'
            )
        except Exception as e:
            logger.error(f"OCR failed: {e}")
            return ""

    def extract_text_from_docx(self, file_path: Path) -> str:
        """Extract text from DOCX files"""
        try:
            doc = docx.Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + " "
                text += "\n"
            return clean_text(text)
        except Exception as e:
            logger.error(f"Error extracting text from DOCX {file_path}: {e}")
            return ""

    def extract_text_from_txt(self, file_path: Path) -> str:
        """Extract text from TXT files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return clean_text(file.read())
        except UnicodeDecodeError:
            with open(file_path, 'r', encoding='latin-1') as file:
                return clean_text(file.read())
        except Exception as e:
            logger.error(f"Error reading TXT file {file_path}: {e}")
            return ""

    def process_document(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Process a single document and return structured data"""
        if file_path.suffix.lower() not in self.supported_formats:
            logger.warning(f"Unsupported file format: {file_path.suffix}")
            return None
        logger.info(f"Processing document: {file_path.name}")
        text = ""
        if file_path.suffix.lower() == '.pdf':
            text = self.extract_text_from_pdf(file_path)
        elif file_path.suffix.lower() in ['.docx', '.doc']:
            text = self.extract_text_from_docx(file_path)
        elif file_path.suffix.lower() == '.txt':
            text = self.extract_text_from_txt(file_path)
        
        if not text.strip():
            logger.warning(f"No text extracted from {file_path.name}")
            return None

        chunks = chunk_text(text, self.config.CHUNK_SIZE, self.config.CHUNK_OVERLAP)
        metadata = extract_metadata(file_path)
        doc_id = generate_document_id(str(file_path))
        return {
            'document_id': doc_id,
            'metadata': metadata,
            'full_text': text,
            'chunks': chunks,
            'chunk_count': len(chunks),
            'processed_date': pd.Timestamp.now().isoformat()
        }

    def process_document_directory(self, directory_path: Path, target_file_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Process all documents in a directory or a specific document if target_file_name is provided.
        """
        processed_docs = []
        if target_file_name:
            file_path = directory_path / target_file_name
            if file_path.is_file() and file_path.suffix.lower() in self.supported_formats:
                doc_data = self.process_document(file_path)
                if doc_data:
                    processed_docs.append(doc_data)
        else:
            for file_path in directory_path.iterdir():
                if file_path.is_file() and file_path.suffix.lower() in self.supported_formats:
                    doc_data = self.process_document(file_path)
                    if doc_data:
                        processed_docs.append(doc_data)
        
        logger.info(f"Processed {len(processed_docs)} documents from {directory_path}")
        return processed_docs
